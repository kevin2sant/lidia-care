
var serverlessSDK = require('./serverless_sdk/index.js');
serverlessSDK = new serverlessSDK({
  orgId: 'lidiakev',
  applicationName: 'my-express-api-lidia-care',
  appUid: 'R31NnNjyDLZTptbCNB',
  orgUid: '1a466789-5558-4273-a276-f7565c3066f8',
  deploymentUid: 'aa724bb0-7dc3-428a-a47c-87d1d2a58c24',
  serviceName: 'my-express-api-lidia-care',
  shouldLogMeta: true,
  shouldCompressLogs: true,
  disableAwsSpans: false,
  disableHttpSpans: false,
  stageName: 'dev',
  serverlessPlatformStage: 'prod',
  devModeEnabled: false,
  accessKey: null,
  pluginVersion: '6.1.5',
  disableFrameworksInstrumentation: false
});

const handlerWrapperArgs = { functionName: 'my-express-api-lidia-care-dev-api', timeout: 6 };

try {
  const userHandler = require('./handler.js');
  module.exports.handler = serverlessSDK.handler(userHandler.handler, handlerWrapperArgs);
} catch (error) {
  module.exports.handler = serverlessSDK.handler(() => { throw error }, handlerWrapperArgs);
}