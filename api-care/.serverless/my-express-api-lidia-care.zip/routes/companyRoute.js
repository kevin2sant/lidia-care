const express 	= require('express')
const company    	= require('../controllers/companyController')

const route 	= express.Router()

route.get('/getDataRegister', company.getDataRegister)
route.get('/companyList', company.companyList)

module.exports = route
